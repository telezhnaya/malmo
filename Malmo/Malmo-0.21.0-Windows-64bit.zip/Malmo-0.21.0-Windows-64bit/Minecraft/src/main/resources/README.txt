XSD files are copied here by build.gradle.
Any changes made to this version will be lost!

If you want to make changes to the schema, edit the one in the Schemas
folder and run 'gradlew build' or 'msbuild' in the Mod folder.
