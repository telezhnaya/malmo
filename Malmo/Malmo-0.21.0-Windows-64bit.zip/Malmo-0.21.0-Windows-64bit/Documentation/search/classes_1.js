var searchData=
[
  ['clientinfo',['ClientInfo',['../structmalmo_1_1_client_info.html',1,'malmo']]],
  ['clientpool',['ClientPool',['../structmalmo_1_1_client_pool.html',1,'malmo']]]
];
