var searchData=
[
  ['missionrecordspec',['MissionRecordSpec',['../structmalmo_1_1_mission_record_spec.html#a0b059f0cc93df4c2848d522bfddc7fbd',1,'malmo::MissionRecordSpec::MissionRecordSpec()'],['../structmalmo_1_1_mission_record_spec.html#a9b521ace513713f5bcc1fd1bf371344c',1,'malmo::MissionRecordSpec::MissionRecordSpec(std::string destination)']]],
  ['missionspec',['MissionSpec',['../classmalmo_1_1_mission_spec.html#a0ca398aa123059fdd2a145b0ebb30cb9',1,'malmo::MissionSpec::MissionSpec()'],['../classmalmo_1_1_mission_spec.html#a564572c6adbc68a2f168453f192e5b8c',1,'malmo::MissionSpec::MissionSpec(const std::string &amp;xml, bool validate)']]]
];
