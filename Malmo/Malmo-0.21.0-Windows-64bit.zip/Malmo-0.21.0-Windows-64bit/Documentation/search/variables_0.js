var searchData=
[
  ['channels',['channels',['../structmalmo_1_1_timestamped_video_frame.html#a0d84d5f94e6a1dacc25c1c99c28af0fc',1,'malmo::TimestampedVideoFrame']]],
  ['clients',['clients',['../structmalmo_1_1_client_pool.html#a84ddb8582b84c153ea651a294bba19a7',1,'malmo::ClientPool']]]
];
