var searchData=
[
  ['reverse_5fscanline',['REVERSE_SCANLINE',['../structmalmo_1_1_timestamped_video_frame.html#a72f071afb831b7e2036255229d676515a814dd49d492ea1aba42588c517e73ad3',1,'malmo::TimestampedVideoFrame']]]
];
