var indexSectionsWithContent =
{
  0: "acdefghiklmnoprstvwxyz~",
  1: "acimptw",
  2: "acdefghikmoprst~",
  3: "cdehimnoprtvwxyz",
  4: "ortv",
  5: "iklrs",
  6: "o",
  7: "im"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions",
  3: "variables",
  4: "enums",
  5: "enumvalues",
  6: "related",
  7: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Functions",
  3: "Variables",
  4: "Enumerations",
  5: "Enumerator",
  6: "Friends",
  7: "Pages"
};

