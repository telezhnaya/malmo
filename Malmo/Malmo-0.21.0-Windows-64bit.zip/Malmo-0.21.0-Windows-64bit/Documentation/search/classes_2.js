var searchData=
[
  ['initialiser',['initialiser',['../structmalmo_1_1initialiser.html',1,'malmo']]]
];
