var searchData=
[
  ['width',['width',['../structmalmo_1_1_timestamped_video_frame.html#aa594366f1adcad9dededcbbaa00f1095',1,'malmo::TimestampedVideoFrame']]]
];
