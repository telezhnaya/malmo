var searchData=
[
  ['width',['width',['../structmalmo_1_1_timestamped_video_frame.html#aa594366f1adcad9dededcbbaa00f1095',1,'malmo::TimestampedVideoFrame']]],
  ['worldstate',['WorldState',['../structmalmo_1_1_world_state.html',1,'malmo']]]
];
