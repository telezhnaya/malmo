var searchData=
[
  ['isrecording',['isRecording',['../structmalmo_1_1_mission_record_spec.html#a5b5bbb7fb58a1722262f3f801ffa55b8',1,'malmo::MissionRecordSpec']]],
  ['isvideorequested',['isVideoRequested',['../classmalmo_1_1_mission_spec.html#af80a194eae7d906b93d5aae293e4cb0e',1,'malmo::MissionSpec']]]
];
